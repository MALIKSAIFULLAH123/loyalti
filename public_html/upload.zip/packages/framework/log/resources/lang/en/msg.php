<?php

/* this is auto generated file */
return [
    'env'       => 'env',
    'level'     => 'Level',
    'message'   => 'Message',
    'timestamp' => 'Timestamp',
];
