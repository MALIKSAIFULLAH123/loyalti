<?php

/* this is auto generated file */
return [
    'can_not_action_on_default_currency'   => 'Can not action on default currency.',
    'country_city_created_successfully'    => 'City was created successfully.',
    'country_city_deleted_successfully'    => 'City was deleted successfully.',
    'country_city_updated_successfully'    => 'City was updated successfully.',
    'country_deleted_successfully'         => 'Country was deleted successfully.',
    'country_state_created_successfully'   => 'Country state was created successfully.',
    'country_state_deleted_successfully'   => 'Country state was deleted successfully.',
    'country_state_updated_successfully'   => 'Country state was updated successfully.',
    'country_successfully_created'         => 'Country was created successfully.',
    'country_updated_successfully'         => 'Country was updated successfully.',
    'currency_deleted_successfully'        => 'Currency was deleted successfully.',
    'currency_successfully_activated'      => 'Currency was activated successfully.',
    'currency_successfully_created'        => 'Currency was created successfully.',
    'currency_successfully_deactived'      => 'Currency was deactivated successfully.',
    'currency_successfully_set_as_default' => 'Currency was set as default successfully.',
    'currency_successfully_updated'        => 'Currency was updated successfully.',
    'language_successfully_activated'      => 'Language was activated successfully.',
    'language_successfully_deactivated'    => 'Language was deactivated successfully.',
    'language_successfully_updated'        => 'Language was updated successfully.',
    'please_choose_default_locale'         => 'Please choose default locale.',
    'timezone_successfully_activated'      => 'Timezone was activated successfully.',
    'timezone_successfully_deactived'      => 'Timezone was deactivated successfully.',
];
