<?php

/* this is auto generated file */
return [
    'currency_code_is_required_field'                 => 'Currency code is a required field.',
    'currency_code_maximum_string_length_description' => 'Currency code must be at most {min} characters.',
    'invalid_format'                                  => 'Invalid format.',
];
