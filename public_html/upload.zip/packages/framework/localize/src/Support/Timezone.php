<?php

namespace MetaFox\Localize\Support;

use MetaFox\Localize\Contracts\TimezoneSupportContract;

/**
 * @deprecated
 */
class Timezone implements TimezoneSupportContract
{
}
