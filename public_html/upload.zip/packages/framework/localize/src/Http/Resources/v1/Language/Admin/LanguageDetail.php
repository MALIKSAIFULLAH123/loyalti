<?php

namespace MetaFox\Localize\Http\Resources\v1\Language\Admin;

/**
 * Class LanguageItem.
 */
class LanguageDetail extends LanguageItem
{
}
