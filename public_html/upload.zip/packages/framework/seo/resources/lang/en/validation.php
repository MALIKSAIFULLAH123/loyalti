<?php

/* this is auto generated file */
return [
    'canonical_url_must_be_valid_url' => '${path} must be a valid URL.',
];
