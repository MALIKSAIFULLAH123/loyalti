<?php

/* this is auto generated file */
return [
    'app_name'               => 'Schedule',
    'job'                    => 'Job',
    'manage_schedule'        => 'Manage Schedule',
    'next_due'               => 'Next Due',
    'schedule'               => 'Schedule',
    'queue_command_guide'    => 'This syntax set the Cron for the queue to run every 5 minutes',
    'queue_status_guide'     => 'You may verify the queue status by reviewing the <b>Queues</b> section within the <a href=":health_check_url">Health Check</a> report.',
    'schedule_command_guide' => 'Sometimes, shared hosting must be used that does not permit the installation of supervisor to run the queue worker. For Cpanel servers, the Cron statement might look like
:command',
    'schedule_jobs'     => 'Schedule Jobs',
    'schedule_settings' => 'Settings',
    'settings'          => 'Settings',
    'schedule_command'  => 'Schedule Command',
    'queue_command'     => 'Queue Command',
];
