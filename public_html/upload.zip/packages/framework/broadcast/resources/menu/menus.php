<?php

/* this is auto generated file */
return [
    [
        'name'       => 'broadcast.sidebarMenu',
        'resolution' => 'web',
        'type'       => 'sidebar',
    ],
    [
        'name'       => 'broadcast.admin',
        'resolution' => 'admin',
        'type'       => 'admin_top',
    ],
];
