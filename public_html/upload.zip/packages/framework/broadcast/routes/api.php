<?php

namespace MetaFox\Broadcast\Http\Controllers\Api;

use Illuminate\Support\Facades\Route;

/*
 | --------------------------------------------------------------------------
 |  API Routes
 | --------------------------------------------------------------------------
 |  This file is booted by App\Providers\RouteServiceProvider::boot()
 |  - prefix by: api/{ver}
 |  - middlewares: 'api.version', 'api'
 |
 |  stub: app/Console/Commands/stubs/routes/api.stub
 */

//Route::controller(Controller::class)
//    ->prefix('resource')
//    ->group(function(){
//
//});

//Route::prefix()
//    ->resource('resource', Controller::class);
